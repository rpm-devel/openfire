/**
 * Laucher classes for Openfire.
 */
package org.jivesoftware.openfire.launcher;
