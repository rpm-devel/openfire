/**
 * Supporting classes and tags for the admin console.
 */
package org.jivesoftware.admin;
