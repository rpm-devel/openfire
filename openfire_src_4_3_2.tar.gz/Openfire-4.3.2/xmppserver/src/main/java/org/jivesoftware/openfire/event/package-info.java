/**
 * Event system.
 */
package org.jivesoftware.openfire.event;
