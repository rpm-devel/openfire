/**
 * Service discovery implementation (XEP-0030).
 */
package org.jivesoftware.openfire.disco;
