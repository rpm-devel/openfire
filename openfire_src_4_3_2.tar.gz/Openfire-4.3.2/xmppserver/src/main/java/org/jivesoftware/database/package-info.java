/**
 * Database connection code.
 */
package org.jivesoftware.database;
