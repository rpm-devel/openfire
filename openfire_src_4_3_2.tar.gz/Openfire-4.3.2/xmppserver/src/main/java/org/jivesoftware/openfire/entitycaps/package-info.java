/**
 * Implementation of Entity Capabilities (XEP-0115).
 */
package org.jivesoftware.openfire.entitycaps;
