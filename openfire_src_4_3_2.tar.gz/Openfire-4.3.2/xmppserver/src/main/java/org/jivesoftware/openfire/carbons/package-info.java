/**
 * Provides packet extensions for <a href="http://xmpp.org/extensions/xep-0280.html">XEP-0280: Message Carbons</a>.
 */
package org.jivesoftware.openfire.carbons;
