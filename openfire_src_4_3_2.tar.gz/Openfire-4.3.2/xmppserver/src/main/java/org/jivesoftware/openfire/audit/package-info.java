/**
 * Service that records XMPP traffics.
 */
package org.jivesoftware.openfire.audit;
